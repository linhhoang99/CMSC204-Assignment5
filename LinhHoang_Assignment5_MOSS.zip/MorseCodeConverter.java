import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * translating
 * morse code from text and file to character
 *
 * @author Linh Hoang
 */
public class MorseCodeConverter {
    

    private static MorseCodeTree tree = new MorseCodeTree();
    public static String convertToEnglish(File selectedFile) throws FileNotFoundException {
        Scanner input = new Scanner(selectedFile);
        String text = "";
        while (input.hasNextLine()) {
            text += input.nextLine();
        }
        return convertToEnglish(text);
    }

 
    public static String printTree() {
        String treeStr = "";
        for (String e : tree.toArrayList()) {
            treeStr += e + " ";
        }
        return treeStr;
    }
    public static String convertToEnglish(String text) {
        String result = "";
        String[] fullCode = text.split("/");
        String[][] codes = new String[fullCode.length][];
        
        for (int i = 0; i < codes.length; i++) {
            codes[i] = fullCode[i].split(" ");
        }
                
        for (int i = 0; i < codes.length; i++) {
            for (int j = 0; j < codes[i].length; j++) {
                codes[i][j] = tree.fetch(codes[i][j]);
                result += codes[i][j];
            }
            result += (i == codes.length - 1) ? "" : " ";
        }
        
        return result;
    }


  

}